import Network from './Network';

const routes = [
  // ...existing routes
  {
    path: '/network',
    element: <Network />,
  },
];

export default routes;
