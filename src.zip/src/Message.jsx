import React, { useEffect, useState, useRef } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { auth, db } from './firebase';
import { 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  onSnapshot, 
  serverTimestamp, 
  doc, 
  getDoc,
  updateDoc,
  arrayUnion 
} from 'firebase/firestore';
import Navbar from './Navbar';
import './message.css';
import { 
  IconButton, 
  TextField, 
  Paper, 
  Typography, 
  Box, 
  Chip, 
  Avatar,
  Tooltip,
  Menu,
  MenuItem,
  Fab
} from '@mui/material';
import { 
  Send, 
  AttachFile, 
  EmojiEmotions, 
  MoreVert, 
  Reply, 
  Delete,
  Edit,
  KeyboardArrowUp
} from '@mui/icons-material';

const Message = ({ postId: propPostId, joinerEmail: propJoinerEmail, hideNavbar }) => {
  const params = useParams();
  const location = useLocation();
  const postId = propPostId || params.postId;
  const joinerEmail = propJoinerEmail || new URLSearchParams(location.search).get('joiner');
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [user, setUser] = useState(null);
  const [post, setPost] = useState(null);
  const [isSending, setIsSending] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [editingMessage, setEditingMessage] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedMessage, setSelectedMessage] = useState(null);
  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);

  useEffect(() => {
    if (!postId) return;
    const unsubscribe = onSnapshot(
      query(collection(db, 'posts', postId, 'messages'), orderBy('createdAt', 'asc')),
      (snapshot) => {
        setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      },
      (error) => {
        console.error('Error listening to messages:', error);
      }
    );
    return () => unsubscribe();
  }, [postId]);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (firebaseUser) => {
      if (firebaseUser && postId) {
        const postRef = doc(db, 'posts', postId);
        const postSnap = await getDoc(postRef);
        setPost(postSnap.exists() ? postSnap.data() : null);
        setUser(firebaseUser);
      } else {
        setUser(null);
      }
    });
    return () => unsubscribe();
  }, [postId]);

  useEffect(() => {
    scrollToBottom();
    
    // Handle scroll to show/hide scroll-to-top button
    const handleScroll = () => {
      if (messagesContainerRef.current) {
        const { scrollTop, scrollHeight, clientHeight } = messagesContainerRef.current;
        setShowScrollTop(scrollHeight - scrollTop - clientHeight > 200);
      }
    };
    
    const container = messagesContainerRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
      return () => container.removeEventListener('scroll', handleScroll);
    }
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const filteredMessages = React.useMemo(() => {
    if (!user || !post) return messages;
    if (user.email === post.email && joinerEmail) {
      return messages.filter(
        msg =>
          (msg.sender === user.email && msg.senderUid === user.uid) ||
          (msg.sender === joinerEmail)
      );
    }
    return messages;
  }, [messages, user, post, joinerEmail]);

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim() || !user || isSending) return;
    
    setIsSending(true);
    setIsTyping(false);
    
    try {
      const messageData = {
        text: input,
        sender: user.email,
        senderUid: user.uid,
        senderName: user.displayName || user.email.split('@')[0],
        createdAt: serverTimestamp(),
        replyTo: replyTo,
        edited: false,
        reactions: []
      };
      
      await addDoc(collection(db, 'posts', postId, 'messages'), messageData);
      setInput('');
      setReplyTo(null);
      setTimeout(scrollToBottom, 100);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsSending(false);
    }
  };

  const handleInputChange = (e) => {
    setInput(e.target.value);
    // Simulate typing indicator
    setIsTyping(true);
    setTimeout(() => setIsTyping(false), 1000);
  };

  const scrollToTop = () => {
    messagesContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleMessageMenu = (event, message) => {
    setAnchorEl(event.currentTarget);
    setSelectedMessage(message);
  };

  const closeMessageMenu = () => {
    setAnchorEl(null);
    setSelectedMessage(null);
  };

  const handleReply = () => {
    setReplyTo(selectedMessage);
    closeMessageMenu();
  };

  const handleEdit = () => {
    setEditingMessage(selectedMessage);
    setInput(selectedMessage.text);
    closeMessageMenu();
  };

  const formatTime = (timestamp) => {
    if (!timestamp?.toDate) return '';
    const date = timestamp.toDate();
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="message-app">
      {!hideNavbar && <Navbar />}
      <div className="chat-container">
        <div className="chat-header">
          {!hideNavbar && (
            <button className="back-btn" onClick={() => window.history.back()}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M19 12H5M12 19L5 12L12 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          )}
          <div className="header-content">
            <h3>{post?.name || 'Chat'}</h3>
            <p>Chatting with {joinerEmail || post?.postedBy || 'Poster'}</p>
          </div>
        </div>
        
        <div className="chat-window">
          {filteredMessages.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 10H8.01M12 10H12.01M16 10H16.01M8 16H18C19.1046 16 20 15.1046 20 14V6C20 4.89543 19.1046 4 18 4H6C4.89543 4 4 4.89543 4 6V14C4 15.1046 4.89543 16 6 16H8V20L12 16H16" stroke="#128C7E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h4>No messages yet</h4>
              <p>Start the conversation by sending a message</p>
            </div>
          ) : (
            <div className="messages-container" ref={messagesContainerRef}>
              {filteredMessages.map(msg => (
                <div
                  key={msg.id}
                  className={`message ${msg.senderUid === user?.uid ? 'sent' : 'received'}`}
                >
                  {msg.senderUid !== user?.uid && (
                    <Avatar sx={{ width: 32, height: 32, bgcolor: '#128C7E', fontSize: '0.9rem' }}>
                      {msg.senderName?.[0]?.toUpperCase() || msg.sender?.[0]?.toUpperCase() || '?'}
                    </Avatar>
                  )}
                  <div className="message-content">
                    {msg.senderUid !== user?.uid && (
                      <Typography variant="caption" className="sender-name">
                        {msg.senderName || msg.sender}
                      </Typography>
                    )}
                    
                    {msg.replyTo && (
                      <div className="reply-context">
                        <Typography variant="caption" color="text.secondary">
                          Replying to: {msg.replyTo.text.substring(0, 50)}...
                        </Typography>
                      </div>
                    )}
                    
                    <div className="message-bubble">
                      <Typography variant="body2" sx={{ lineHeight: 1.4 }}>
                        {msg.text}
                      </Typography>
                      
                      <div className="message-footer">
                        <Typography variant="caption" className="message-time">
                          {formatTime(msg.createdAt)}
                          {msg.edited && <span className="edited-indicator"> (edited)</span>}
                        </Typography>
                        
                        {msg.senderUid === user?.uid && (
                          <IconButton 
                            size="small" 
                            onClick={(e) => handleMessageMenu(e, msg)}
                            sx={{ ml: 1, opacity: 0.7 }}
                          >
                            <MoreVert fontSize="small" />
                          </IconButton>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="typing-indicator">
                  <div className="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                  <Typography variant="caption" color="text.secondary">
                    Someone is typing...
                  </Typography>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          )}
          
          {replyTo && (
            <Paper className="reply-preview" elevation={1}>
              <Typography variant="caption" color="primary">
                Replying to: {replyTo.senderName || replyTo.sender}
              </Typography>
              <Typography variant="body2" noWrap>
                {replyTo.text}
              </Typography>
              <IconButton size="small" onClick={() => setReplyTo(null)}>
                <Delete fontSize="small" />
              </IconButton>
            </Paper>
          )}
          
          <form className="message-input-area" onSubmit={sendMessage}>
            <div className="input-wrapper">
              <TextField
                fullWidth
                variant="outlined"
                placeholder="Type a message..."
                value={input}
                onChange={handleInputChange}
                disabled={!user}
                multiline
                maxRows={4}
                size="small"
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '20px',
                    backgroundColor: 'white'
                  }
                }}
              />
              
              <div className="input-actions">
                <IconButton size="small" disabled>
                  <AttachFile />
                </IconButton>
                <IconButton size="small" disabled>
                  <EmojiEmotions />
                </IconButton>
                <IconButton
                  type="submit"
                  disabled={!input.trim() || !user || isSending}
                  sx={{ 
                    backgroundColor: '#128C7E',
                    color: 'white',
                    '&:hover': { backgroundColor: '#0d7a6b' },
                    '&:disabled': { backgroundColor: '#a5a5a5' }
                  }}
                >
                  <Send />
                </IconButton>
              </div>
            </div>
          </form>
          
          {showScrollTop && (
            <Fab
              size="small"
              color="primary"
              onClick={scrollToTop}
              sx={{
                position: 'absolute',
                bottom: 100,
                right: 16,
                backgroundColor: '#128C7E',
                '&:hover': { backgroundColor: '#0d7a6b' }
              }}
            >
              <KeyboardArrowUp />
            </Fab>
          )}
        </div>
        
        {/* Message Context Menu */}
        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={closeMessageMenu}
        >
          <MenuItem onClick={handleReply}>
            <Reply fontSize="small" sx={{ mr: 1 }} />
            Reply
          </MenuItem>
          <MenuItem onClick={handleEdit}>
            <Edit fontSize="small" sx={{ mr: 1 }} />
            Edit
          </MenuItem>
        </Menu>
      </div>
    </div>
  );
};

export default Message;