import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from './firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { List, ListItem, ListItemText, CircularProgress, Box, Typography, Dialog } from '@mui/material';
import Message from './Message'; // Import the Message component

const MyChats = () => {
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activePost, setActivePost] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchChats = async () => {
      try {
        const user = auth.currentUser;
        if (!user) {
          navigate('/signin');
          return;
        }
        // Fetch all posts by this user
        const postsQuery = query(collection(db, 'posts'), where('uid', '==', user.uid));
        const postsSnap = await getDocs(postsQuery);
        // Show all posts, not just those with joiners
        const postList = postsSnap.docs.map(doc => ({
          postId: doc.id,
          postTitle: doc.data().name || 'Untitled',
          description: doc.data().description || '',
          createdAt: doc.data().createdAt,
          joiners: Array.isArray(doc.data().joiners) ? doc.data().joiners.filter(j => !!j) : []
        }));
        setChats(postList);
      } catch (error) {
        console.error('Error fetching posts:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchChats();
  }, [navigate]);

  const handleChatClick = (postId, joinerEmail) => {
    navigate(`/message/${postId}?joiner=${encodeURIComponent(joinerEmail)}`);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', flexDirection: 'column', gap: 2 }}>
        <CircularProgress size={60} />
        <Typography variant="h6">Loading your chats...</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ maxWidth: 900, margin: 'auto', mt: 4 }}>
      <Typography variant="h5" gutterBottom>My Posts</Typography>
      <List>
        {chats.length === 0 ? (
          <Typography>No posts found.</Typography>
        ) : (
          chats.map((chat) => (
            <ListItem 
              key={chat.postId}
              alignItems="flex-start"
              sx={{ flexDirection: 'column', alignItems: 'flex-start', mb: 2, border: '1px solid #e0e0e0', borderRadius: 2, p: 2, background: activePost && activePost.postId === chat.postId ? '#f5f5f5' : '#fff' }}
              onClick={() => setActivePost(chat)}
              button
              selected={activePost && activePost.postId === chat.postId}
            >
              <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>{chat.postTitle}</Typography>
              {chat.description && (
                <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>{chat.description}</Typography>
              )}
              {chat.createdAt && (
                <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5 }}>
                  {typeof chat.createdAt.toDate === 'function' ? chat.createdAt.toDate().toLocaleDateString() : ''}
                </Typography>
              )}
              {chat.joiners.length > 0 && (
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  Joiners: {chat.joiners.join(', ')}
                </Typography>
              )}
            </ListItem>
          ))
        )}
      </List>
      <Dialog open={!!activePost} onClose={() => setActivePost(null)} fullScreen>
        {activePost && (
          <Box sx={{ width: '100vw', height: '100vh', bgcolor: '#f9f9f9', p: { xs: 0, sm: 2 } }}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
              <Typography
                variant="button"
                sx={{ cursor: 'pointer', fontWeight: 700, color: '#142850', fontSize: 22 }}
                onClick={() => setActivePost(null)}
              >
                ✕
              </Typography>
            </Box>
            <Message postId={activePost.postId} hideNavbar />
          </Box>
        )}
      </Dialog>
    </Box>
  );
};

export default MyChats;
